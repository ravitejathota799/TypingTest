let submitBtnE1 = document.getElementById("submitBtn");
let resetBtnE1 = document.getElementById("resetBtn");
let resultPara = document.getElementById("result");
let quoteDisplayE1 = document.getElementById("quoteDisplay");
let quoteInputE1 = document.getElementById("quoteInput");
let spinnerE1 = document.getElementById("spinner");
let timerE1 = document.getElementById("timer");

let counter = 0;

let counterTimer = function() {
    counter = counter + 1;
    timerE1.textContent = counter + "seconds";
};

let intervalId = setInterval(counterTimer, 1000);



function send() {

    let url = "https://apis.ccbp.in/random-quote";
    let options = {
        method: "GET"
    }
    spinnerE1.classList.remove("d-none");
    fetch(url, options)
        .then(function(response) {
            return response.text();
        })
        .then(function(Data) {
            spinnerE1.classList.add("d-none");
            let text = JSON.parse(Data);
            console.log(text);
            quoteDisplayE1.textContent = Data;
        })
}

submitBtnE1.addEventListener("click", function() {
    if (quoteInputE1.value === "" || quoteInputE1.value === quoteDisplayE1) {
        resultPara.textContent = "enter the correct value";
    } else {
        resultPara.textContent = "you typed in the correct!"
        clearInterval(intervalId);
    }
});

resetBtnE1.addEventListener("click", function() {
    counter = 0;
    clearInterval(counterTimer + "seconds");
    send();
});

send();